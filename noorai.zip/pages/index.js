import React from 'react';

export default function Home() {
  return (
    <main style={{ fontFamily: 'Arial', padding: 20 }}>
      <h1 style={{ color: 'teal' }}>NoorAi</h1>
      <p>AI-powered Islamic assistant. Ask questions, learn Quran insights, and more.</p>
    </main>
  );
}
